<template>

  <v-card elevation="10">
      <formulario></formulario>
  </v-card>

</template>